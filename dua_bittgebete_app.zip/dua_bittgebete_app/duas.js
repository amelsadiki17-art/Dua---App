const DUAS = [
  {
    "id": 1,
    "category": "Vergebung",
    "title": "Um Vergebung bitten",
    "ar": "رَبَّنَا ظَلَمْنَا أَنْفُسَنَا وَإِنْ لَمْ تَغْفِرْ لَنَا وَتَرْحَمْنَا لَنَكُونَنَّ مِنَ الْخَاسِرِينَ",
    "latin": "Rabbanā ẓalamnā anfusanā wa in lam taghfir lanā wa tarḥamnā lanakūnanna mina l-khāsirīn.",
    "de": "Unser Herr, wir haben uns selbst Unrecht getan. Wenn Du uns nicht vergibst und Dich unser erbarmst, werden wir gewiss zu den Verlierern gehören.",
    "source": "Koran 7:23",
    "kind": "Koran"
  },
  {
    "id": 2,
    "category": "Wissen",
    "title": "Um mehr Wissen bitten",
    "ar": "رَبِّ زِدْنِي عِلْمًا",
    "latin": "Rabbi zidnī ʿilmā.",
    "de": "Mein Herr, mehre mein Wissen.",
    "source": "Koran 20:114",
    "kind": "Koran"
  },
  {
    "id": 3,
    "category": "Versorgung",
    "title": "Um Gutes bitten",
    "ar": "رَبِّ إِنِّي لِمَا أَنْزَلْتَ إِلَيَّ مِنْ خَيْرٍ فَقِيرٌ",
    "latin": "Rabbi innī limā anzalta ilayya min khayrin faqīr.",
    "de": "Mein Herr, ich bin wahrlich auf das Gute angewiesen, das Du mir zukommen lässt.",
    "source": "Koran 28:24",
    "kind": "Koran"
  },
  {
    "id": 4,
    "category": "Schutz",
    "title": "Auf Allah vertrauen",
    "ar": "حَسْبُنَا اللَّهُ وَنِعْمَ الْوَكِيلُ",
    "latin": "Ḥasbunallāhu wa niʿma l-wakīl.",
    "de": "Allah genügt uns, und Er ist der beste Sachwalter.",
    "source": "Koran 3:173",
    "kind": "Koran"
  },
  {
    "id": 5,
    "category": "Wohlbefinden",
    "title": "Um Vergebung und Wohlergehen bitten",
    "ar": "اللَّهُمَّ إِنِّي أَسْأَلُكَ الْعَفْوَ وَالْعَافِيَةَ",
    "latin": "Allāhumma innī asʾaluka l-ʿafwa wa l-ʿāfiyah.",
    "de": "O Allah, ich bitte Dich um Vergebung und Wohlergehen.",
    "source": "Überliefertes Bittgebet; gekürzter Wortlaut",
    "kind": "Überliefertes Bittgebet"
  },
  {
    "id": 6,
    "category": "Schutz",
    "title": "Schutz durch Allahs Namen suchen",
    "ar": "بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ",
    "latin": "Bismi llāhi lladhī lā yaḍurru maʿa-smihi shayʾun fi l-arḍi wa lā fi s-samāʾi wa huwa s-samīʿu l-ʿalīm.",
    "de": "Im Namen Allahs, mit dessen Namen nichts auf der Erde und im Himmel Schaden zufügen kann. Er ist der Allhörende, der Allwissende.",
    "source": "Überliefertes Bittgebet",
    "kind": "Überliefertes Bittgebet"
  },
  {
    "id": 7,
    "category": "Alltag",
    "title": "Gutes im Diesseits und Jenseits erbitten",
    "ar": "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ",
    "latin": "Rabbanā ātinā fi d-dunyā ḥasanatan wa fi l-ākhirati ḥasanatan wa qinā ʿadhāba n-nār.",
    "de": "Unser Herr, gib uns im Diesseits Gutes und im Jenseits Gutes und bewahre uns vor der Strafe des Feuers.",
    "source": "Koran 2:201",
    "kind": "Koran"
  },
  {
    "id": 8,
    "category": "Familie",
    "title": "Für die Eltern bitten",
    "ar": "رَبِّ ارْحَمْهُمَا كَمَا رَبَّيَانِي صَغِيرًا",
    "latin": "Rabbi rḥamhumā kamā rabbayānī ṣaghīrā.",
    "de": "Mein Herr, erbarme Dich ihrer, so wie sie mich aufgezogen haben, als ich klein war.",
    "source": "Koran 17:24",
    "kind": "Koran"
  },
  {
    "id": 9,
    "category": "Vergebung",
    "title": "Kurz um Vergebung bitten",
    "ar": "أَسْتَغْفِرُ اللَّهَ",
    "latin": "Astaghfirullāh.",
    "de": "Ich bitte Allah um Vergebung.",
    "source": "Gebräuchliche islamische Bitte um Vergebung",
    "kind": "Dhikr"
  },
  {
    "id": 10,
    "category": "Geduld",
    "title": "Um Geduld bitten",
    "ar": "رَبَّنَا أَفْرِغْ عَلَيْنَا صَبْرًا",
    "latin": "Rabbanā afrigh ʿalaynā ṣabrā.",
    "de": "Unser Herr, gieße Geduld über uns aus.",
    "source": "Koran 2:250",
    "kind": "Koran"
  },
  {
    "id": 11,
    "category": "Schutz",
    "title": "Zuflucht vor dem Satan suchen",
    "ar": "أَعُوذُ بِاللَّهِ مِنَ الشَّيْطَانِ الرَّجِيمِ",
    "latin": "Aʿūdhu billāhi mina sh-shayṭāni r-rajīm.",
    "de": "Ich suche Zuflucht bei Allah vor dem verstoßenen Satan.",
    "source": "Koran 16:98 (Formulierung der Zufluchtsbitte)",
    "kind": "Koranische Formulierung"
  },
  {
    "id": 12,
    "category": "Wissen",
    "title": "Um Erleichterung bitten",
    "ar": "رَبِّ اشْرَحْ لِي صَدْرِي وَيَسِّرْ لِي أَمْرِي",
    "latin": "Rabbi shraḥ lī ṣadrī wa yassir lī amrī.",
    "de": "Mein Herr, öffne mir meine Brust und erleichtere mir meine Aufgabe.",
    "source": "Koran 20:25–26",
    "kind": "Koran"
  }
];
