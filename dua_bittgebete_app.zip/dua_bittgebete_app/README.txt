Duʿāʾ – Bittgebete verstehen (PWA-Prototyp)

Dateien:
- index.html: Oberfläche
- duas.js: Startauswahl an Gebeten
- app.js: Suche, Kategorien, Favoriten, Kopieren und Audioausgabe
- manifest.webmanifest: Installations-Metadaten
- sw.js: Offline-Caching (Service Worker)

WICHTIG:
1. Service Worker und Installation benötigen in der Regel HTTPS oder localhost. Doppelklick auf index.html zeigt die App, aber Offline-Caching/Installation funktioniert dann nicht zuverlässig.
2. Zum lokalen Testen: im Ordner einen lokalen Webserver starten (z.B. `python -m http.server 8000`) und http://localhost:8000 öffnen.
3. Für eine öffentliche Nutzung die Dateien auf einen HTTPS-Host deployen.
4. Audio verwendet die arabische Sprachstimme des Geräts/Browsers, sofern vorhanden. Das ist keine geprüfte Rezitation und kann ungenau sein.
5. Favoriten werden lokal im Browser gespeichert. Der Browser kann sie bei Datenlöschung entfernen.
6. Dies ist ein Startprototyp, keine vollständige oder abschließend religiös geprüfte Sammlung. Quellen und exakter Wortlaut sollten vor Veröffentlichung von einer qualifizierten Person geprüft werden.
